# -*- coding: utf-8 -*-
"""Imports for the bencode parser."""

from plaso.parsers.bencode_plugins import transmission
from plaso.parsers.bencode_plugins import utorrent
