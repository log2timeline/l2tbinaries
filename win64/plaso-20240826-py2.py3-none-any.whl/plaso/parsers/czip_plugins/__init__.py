# -*- coding: utf-8 -*-
"""Imports for the compound ZIP parser."""

from plaso.parsers.czip_plugins import oxml
