# -*- coding: utf-8 -*-
"""Attribute Container Storage (ACStore).

ACStore, or Attribute Container Storage, provides a stand-alone implementation
to read and write plaso storage files.
"""

__version__ = '20240407'
