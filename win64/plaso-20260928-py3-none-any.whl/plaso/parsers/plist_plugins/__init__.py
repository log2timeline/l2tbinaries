"""Imports for the plist parser plugins."""

from plaso.parsers.plist_plugins import airport
from plaso.parsers.plist_plugins import apple_account
from plaso.parsers.plist_plugins import bluetooth
from plaso.parsers.plist_plugins import default
from plaso.parsers.plist_plugins import install_history
from plaso.parsers.plist_plugins import ios_carplay
from plaso.parsers.plist_plugins import ios_identityservices
from plaso.parsers.plist_plugins import ios_mobilebackup
from plaso.parsers.plist_plugins import ios_siminfo
from plaso.parsers.plist_plugins import ios_wifi_known_networks
from plaso.parsers.plist_plugins import ipod
from plaso.parsers.plist_plugins import launchd
from plaso.parsers.plist_plugins import macos_background_items
from plaso.parsers.plist_plugins import macos_login_items
from plaso.parsers.plist_plugins import macos_login_window
from plaso.parsers.plist_plugins import macos_startup_item
from plaso.parsers.plist_plugins import macos_user
from plaso.parsers.plist_plugins import safari_downloads
from plaso.parsers.plist_plugins import safari_history
from plaso.parsers.plist_plugins import software_update
from plaso.parsers.plist_plugins import spotlight_searched_terms
from plaso.parsers.plist_plugins import spotlight_volume
from plaso.parsers.plist_plugins import time_machine
