# -*- coding: utf-8 -*-
"""ForensicArtifacts.com Artifact Repository."""

__version__ = '20240518'
